deps <- c("RcppTN","abind","clue","coda","doParallel","furrr","pgdraw","posterior","psych","mvtnorm","pks","edmdata")
install.packages(setdiff(deps, rownames(installed.packages())))

path <- "D:/hmdcm_0.1.0.zip"

utils::install.packages(path, repos = NULL, type = "binary")
library("pks"); data("probability"); probability <- as.data.frame(probability)
f <- do.call(cbind, probability[,c("b101", "b102", "b103", "b104", "b105", "b106", "b107", "b108", "b109", "b110", "b111", "b112")])
s <- do.call(cbind, probability[,c("b201", "b202", "b203", "b204", "b205", "b206", "b207", "b208", "b209", "b210", "b211", "b212")])

# keep <- rowSums(is.na(f))==0 & rowSums(is.na(s))==0 & !(rowSums(f) %in% c(0,ncol(f)) | rowSums(s) %in% c(0,ncol(f)))
keep <- rowSums(is.na(f))==0 & rowSums(is.na(s))==0
f <- f[keep,,drop=FALSE]
s <- s[keep,,drop=FALSE]
res = list(f, s)

# K = 3
# QQ = matrix(c(1,0,0,0,1,0,0,1,0,1,0,0,0,0,1,0,1,0,0,1,0,0,1,0,0,0,1,1,0,0,1,0,0,1,1,0),12,3,byrow=T) # Q matrix estimates from Table 3 of Liu and Culpepper (2023)
# QQ = rep(list(QQ), 2)
# # beta_sd=c(2,2,2,2)
# beta_sd=c(2,1.5,0.5,0.5)
# itemtype_string_list = list(  rep("SDCM",nrow(QQ[[1]])), rep("SDCM",nrow(QQ[[2]]))  )
# att_same_index = list(); att_same_index[[1]] = list(c(1,2,3),c(1,2,3))

K = 4
library("edmdata"); QQ = rep(list(qmatrix_probability_part_one), 2)
beta_sd=c(2,1.5,0.5,0.5)
# beta_sd=c(2,2,2,2)
itemtype_string_list = list(  rep("SDCM",nrow(QQ[[1]])), rep("SDCM",nrow(QQ[[2]]))  )
att_same_index = list(); att_same_index[[1]] = list(c(1,2,3,4),c(1,2,3,4))

# K = 5
# QQ = rbind(diag(5),diag(5),diag(5)); QQ = QQ[1:12,]
# QQ = rep(list(QQ), 2)
# beta_sd=c(2,1.5,0.5,0.5)
# beta_sd=c(2,2,2,2)
# itemtype_string_list = list(  rep("SDCM",nrow(QQ[[1]])), rep("SDCM",nrow(QQ[[2]]))  )
# att_same_index = list(); att_same_index[[1]] = list(c(1,2,3,4,5),c(1,2,3,4,5))



nondecreasing = TRUE
equality = FALSE

library("hmdcm")
times <- system.time(a <- hmdcm(res,K=sapply(QQ, ncol),itemtype_string=itemtype_string_list,identifiable_type=1,QQ_target=QQ,burnin=50000,keep=100000
                                ,nondecreasing=nondecreasing,att_same_index=att_same_index,nchains=2,para=T,rand.seed=1
                                ,beta_sd=beta_sd
                                ,equal_QQ=equality,equal_item=equality,equal_transition=equality)  
)

a$est$attribute$time1$mean # attribute probability estimates
a$est$QQ_sample$time1$mean # Q probability estimates
a$est$class_prob$time1$mean # class proportion estimates
a$est$transition$time1$mean # transition matrix estimates