
deps <- c("RcppTN","abind","clue","coda","doParallel","furrr","pgdraw","posterior","psych","mvtnorm","pks","edmdata")
install.packages(setdiff(deps, rownames(installed.packages())))
path <- "D:\\hmdcm_0.1.0.zip" # <--- modify the path on your end
utils::install.packages(path, repos = NULL, type = "binary")
library("pks"); data("probability"); probability <- as.data.frame(probability)
f <- do.call(cbind, probability[,c("b101", "b102", "b103", "b104", "b105", "b106", "b107", "b108", "b109", "b110", "b111", "b112")])
s <- do.call(cbind, probability[,c("b201", "b202", "b203", "b204", "b205", "b206", "b207", "b208", "b209", "b210", "b211", "b212")])
keep <- rowSums(is.na(f))==0 & rowSums(is.na(s))==0
f <- f[keep,,drop=FALSE]; s <- s[keep,,drop=FALSE]; res <- list(f, s)
library("edmdata"); QQ <- rep(list(qmatrix_probability_part_one), 2)
itemtype_string_list <- list(rep("SDCM",nrow(QQ[[1]])), rep("SDCM",nrow(QQ[[2]])))
att_same_index <- list(); att_same_index[[1]] <- list(c(1,2,3,4),c(1,2,3,4))
library("hmdcm"); a <-  hmdcm(res,K=sapply(QQ,ncol),itemtype_string=list(rep("SDCM",nrow(QQ[[1]])),rep("SDCM",nrow(QQ[[2]]))),identifiable_type=1,QQ_target=QQ,burnin=50000,keep=100000,beta_sd=c(2,1.5,0.5,0.5),nondecreasing=TRUE,att_same_index=att_same_index,nchains=2,para=T,rand.seed=1,equal_QQ=FALSE,equal_item=FALSE,equal_transition=FALSE)  
a$est$attribute$time1$mean # attribute probability estimates at Time 1
a$est$QQ_sample$time1$mean # Q probability estimates at Time 1
a$est$class_prob$time1$mean # class proportion estimates at Time 1
a$est$transition$time1$mean # transition matrix estimates at Time 1
a$est$beta$time1$mean # item parameter estimates at Time 1
a$est_full$eta$time1$mean # item response probability estimates at Time 1
a$waic_overall$waic # WAIC
